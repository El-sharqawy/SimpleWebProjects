let deckId;
let remainingCards = 0;
let myScore = 0;
let computerScore = 0;
const cardsContainer = document.getElementById("cards");
const newDeckBtn = document.getElementById("find-btn");
const drawBtn = document.getElementById("draw-btn");

document.querySelector("#remaining-cards").textContent = " " + remainingCards;
document.querySelector("#computer-score").textContent = " " + computerScore;
document.querySelector("#my-score").textContent = " " + myScore;

const Cards = [
    { card: "2",        value: 0 },
    { card: "3",        value: 1 },
    { card: "4",        value: 2 },
    { card: "5",        value: 3 },
    { card: "6",        value: 4 },
    { card: "7",        value: 5 },
    { card: "8",        value: 6 },
    { card: "9",        value: 7 },
    { card: "10",       value: 8 },
    { card: "JACK",     value: 9 },
    { card: "QUEEN",    value: 10 },
    { card: "KING",     value: 11 },
    { card: "ACE",      value: 12 }
]

checkDrawBtn();
newDeckBtn.addEventListener("click", () => {
    fetch("https://www.deckofcardsapi.com/api/deck/new/shuffle/")
        .then(res => res.json())
        .then(data => {
            console.log(data);
            deckId = data.deck_id;
            remainingCards = data.remaining;
            document.querySelector("#remaining-cards").textContent = " " + remainingCards;
            document.querySelector("#winner-text2").textContent = "";
            myScore = 0;
            computerScore = 0;
            document.querySelector("#computer-score").textContent = " " + computerScore;
            document.querySelector("#my-score").textContent = " " + myScore;
            document.querySelector("#winner-text").textContent = "Cards War";
            checkDrawBtn();
        })
})

drawBtn.addEventListener("click", () => {
    fetch(`https://www.deckofcardsapi.com/api/deck/${deckId}/draw/?count=2`)
    .then(res => res.json())
    .then(data => { 
        console.log(data.cards);
        if (remainingCards === 0) {
            document.querySelector("#winner-text").textContent = "Game is Over.";
            newDeckBtn.textContent = "Start New Round";
            if (myScore > computerScore) {
                document.querySelector("#winner-text2").textContent = "You won the game!";
            } else if (myScore < computerScore) {
                document.querySelector("#winner-text2").textContent = "Computer won the game!";
            }
        } else {
            document.querySelector("#cards").children[0].innerHTML = `
                <img class="card" src=${data.cards[0].image} />
            `
            document.querySelector("#cards").children[1].innerHTML = `
                <img class="card" src=${data.cards[1].image} />
            `
            remainingCards -= 2;
            checkCards(data.cards[0].value, data.cards[1].value)
        }
    })
})

function checkDrawBtn () {
    if (deckId == undefined)
        document.getElementById("draw-btn").style.visibility = 'hidden';
    else
        document.getElementById("draw-btn").style.visibility = 'visible';
}

function checkCards(card1, card2) {
    let card_one = Cards.find(firstCard => firstCard.card === card1);
    let card_two = Cards.find(SecondCard => SecondCard.card === card2);
	let card_one_value = card_one.value;
    let card_two_value = card_two.value;
    document.querySelector("#remaining-cards").textContent = " " + remainingCards;
    if (card_one_value > card_two_value) {
        document.querySelector("#winner-text").textContent = "Computer Won!";
        computerScore += 5;
        document.querySelector("#computer-score").textContent = " " + computerScore;
    } else if (card_one_value === card_two_value) {
        document.querySelector("#winner-text").textContent = "None Won.";
    } else if (card_one_value < card_two_value) {
        document.querySelector("#winner-text").textContent = "You Won!";
        myScore += 5;
        document.querySelector("#my-score").textContent = " " + myScore;
    }
}
