const width = 28;
const grid = document.querySelector(".grid");
const scoreDisplay = document.getElementById("score");
let squares = [];
let score = 0;
let topID, downID, rightID, leftID;

// coding
// 28 * 28 = 784 item
/*
    0 - Pac-dots
    1 - wall
    2 - ghost-liar
    3 - power-pellet
    4 - empty
*/
const layout = [
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
    1,3,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,3,1,
    1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,4,4,4,4,4,4,4,4,4,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,1,1,1,2,2,1,1,1,4,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,1,2,2,2,2,2,2,1,4,1,1,0,1,1,1,1,1,1,
    4,4,4,4,4,4,0,0,0,4,1,2,2,2,2,2,2,1,4,0,0,0,4,4,4,4,4,4,
    1,1,1,1,1,1,0,1,1,4,1,2,2,2,2,2,2,1,4,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,1,1,1,1,1,1,1,1,4,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,1,1,1,1,1,1,1,1,4,1,1,0,1,1,1,1,1,1,
    1,0,0,0,0,0,0,0,0,4,4,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
    1,3,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,3,1,
    1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,
    1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,
    1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,1,
    1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,
    1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
];

  // create board
function createBoard() {
    for (let i = 0; i < layout.length; i++) {
        // create square !
        const square = document.createElement("div");
        //put sqaure in grid
        grid.appendChild(square);
        // put square in squares array
        squares.push(square);
        if (layout[i] === 0) {
            squares[i].classList.add("pac-dot");
        } else if (layout[i] === 1) {
            squares[i].classList.add("wall");
        } else if (layout[i] == 2) {
            squares[i].classList.add("ghost-lair");
        } else if (layout[i] === 3) {
            squares[i].classList.add("power-pellet");
        }
    }
}
createBoard();

// starting position !
let pacmanCurrentIndex = 490;
squares[pacmanCurrentIndex].classList.add("pacman");
squares[pacmanCurrentIndex].classList.add("pac-man");

function control(e) {
    squares[pacmanCurrentIndex].classList.remove("pacman");
    squares[pacmanCurrentIndex].classList.remove("pac-man");
    switch (e.keyCode) {
        case 40: // move Down
        {
            if (leftID) { 
                clearInterval(leftID);
                leftID = null;
            }
            if (rightID) { 
                clearInterval(rightID);
                rightID = null;
            }
            if (topID) { 
                clearInterval(topID);
                topID = null;
            }

            if (downID) {
                clearInterval(downID);
                downID = null;
            } else {
                downID = setInterval(moveDown, 100);
            }
        }
        break;
        case 39: // move Right
         {
            if (leftID) { 
                clearInterval(leftID);
                leftID = null;
            }
            if (downID) { 
                clearInterval(downID);
                downID = null;
            }
            if (topID) { 
                clearInterval(topID);
                topID = null;
            }

            if (rightID) {
                clearInterval(rightID);
                rightID = null;
            } else {
                rightID = setInterval(moveRight, 100);
            }
        }
         break;
        case 37: // move Left
        {
            if (rightID) { 
                clearInterval(rightID);
                rightID = null;
            }
            if (downID) { 
                clearInterval(downID);
                downID = null;
            }
            if (topID) { 
                clearInterval(topID);
                topID = null;
            }

            if (leftID) {
                clearInterval(leftID);
                leftID = null;
            } else {
                leftID = setInterval(moveLeft, 100);
            }
        }
        break;
        case 38: // move Up
        {
            if (rightID) { 
                clearInterval(rightID);
                rightID = null;
            }
            if (downID) { 
                clearInterval(downID);
                downID = null;
            }
            if (leftID) { 
                clearInterval(leftID);
                leftID = null;
            }
        
            if (topID) {
                clearInterval(topID);
                topID = null;
            } else {
                topID = setInterval(moveUp, 100);
            }
        }
        break;
    }
    squares[pacmanCurrentIndex].classList.add("pacman");
    squares[pacmanCurrentIndex].classList.add("pac-man");
    pacDotEaten();
    powerPelletEaten();
    checkGameOver();
    checkForWin();
}

document.addEventListener('keyup', control);

function moveDown() {
    squares[pacmanCurrentIndex].classList.remove("pacman");
    squares[pacmanCurrentIndex].classList.remove("pac-man");
    if (!squares[pacmanCurrentIndex + width].classList.contains("ghost-lair") &&
        !squares[pacmanCurrentIndex + width].classList.contains("wall") &&
        pacmanCurrentIndex + width < width * width){
        pacmanCurrentIndex += width;
    }
    squares[pacmanCurrentIndex].classList.add("pacman");
    squares[pacmanCurrentIndex].classList.add("pac-man");
    pacDotEaten();
    powerPelletEaten();
    checkGameOver();
    checkForWin();
}

function moveLeft() {
    squares[pacmanCurrentIndex].classList.remove("pacman");
    squares[pacmanCurrentIndex].classList.remove("pac-man");
    if (!squares[pacmanCurrentIndex - 1].classList.contains("ghost-lair") &&
        !squares[pacmanCurrentIndex - 1].classList.contains("wall") &&
        pacmanCurrentIndex % width !== 0) {
        pacmanCurrentIndex--;
    }
    if (pacmanCurrentIndex === 364) {
        pacmanCurrentIndex = 391;
    }
    squares[pacmanCurrentIndex].classList.add("pacman");
    squares[pacmanCurrentIndex].classList.add("pac-man");
    pacDotEaten();
    powerPelletEaten();
    checkGameOver();
    checkForWin();
}

function moveRight() {
    squares[pacmanCurrentIndex].classList.remove("pacman");
    squares[pacmanCurrentIndex].classList.remove("pac-man");
    if (!squares[pacmanCurrentIndex + 1].classList.contains("ghost-lair") &&
        !squares[pacmanCurrentIndex + 1].classList.contains("wall") &&
        pacmanCurrentIndex % width < width - 1) {
        pacmanCurrentIndex++;
    }
    if (pacmanCurrentIndex === 391) {
        pacmanCurrentIndex = 364;
    }
    squares[pacmanCurrentIndex].classList.add("pacman");
    squares[pacmanCurrentIndex].classList.add("pac-man");
    pacDotEaten();
    powerPelletEaten();
    checkGameOver();
    checkForWin();
}

function moveUp() {
    squares[pacmanCurrentIndex].classList.remove("pacman");
    squares[pacmanCurrentIndex].classList.remove("pac-man");
    if (!squares[pacmanCurrentIndex - width].classList.contains("ghost-lair") &&
        !squares[pacmanCurrentIndex - width].classList.contains("wall") &&
        pacmanCurrentIndex - width >= 0){
        pacmanCurrentIndex -= width;
     }
    squares[pacmanCurrentIndex].classList.add("pacman");
    squares[pacmanCurrentIndex].classList.add("pac-man");
    pacDotEaten();
    powerPelletEaten();
    checkGameOver();
    checkForWin();
}

function pacDotEaten() {
    if (squares[pacmanCurrentIndex].classList.contains("pac-dot")) {
        score++;
        scoreDisplay.innerHTML = score;
        squares[pacmanCurrentIndex].classList.remove("pac-dot");
    }
}

class Ghosts {
    constructor(className, startIndex, speed) {
        this.className = className;
        this.startIndex = startIndex;
        this.speed = speed;
        this.currentIndex = startIndex;
        this.isScared = false;
        this.timerID = NaN;
    }
}

const ghosts = [
    new Ghosts("blinky", 348, 250),
    new Ghosts("pinky", 376, 400),
    new Ghosts('inky', 351, 300),
    new Ghosts('clyde', 379, 500)
]

// draw ghosts in the grid
ghosts.forEach(ghost => {
    squares[ghost.currentIndex].classList.add(ghost.className);
    squares[ghost.currentIndex].classList.add("ghost")
});

// our func to move ghosts !
ghosts.forEach(ghost => moveGhosts(ghost));

function powerPelletEaten() {
    // if square pac-man is in contains a power pellet 
    if (squares[pacmanCurrentIndex].classList.contains("power-pellet")) {
        score += 10;
        ghosts.forEach(ghost => ghost.isScared = true);
        setTimeout(() => {
            ghosts.forEach(ghost => ghost.isScared = false);
        }, 100000);
        squares[pacmanCurrentIndex].classList.remove("power-pellet");
        scoreDisplay.innerHTML = score;
    }
    // add += to score !
    // change each of the four ghosts to isScared !
    // use setTimeout to unscare ghosts after 10 seconds.
}

function moveGhosts(ghost) {
    const Dir = [-1, +1, width, -width];
    let direction = Dir[Math.floor(Math.random() * Dir.length)];
    console.log(direction);
    ghost.timerID = setInterval(() => {
        // our code to move them
        // check if next sqaure doesn't contain a wall or ghost
        if (!squares[ghost.currentIndex + direction].classList.contains("wall") &&
        !squares[ghost.currentIndex + direction].classList.contains("ghost")) {
            // remove any ghost
            squares[ghost.currentIndex].classList.remove(ghost.className);
            squares[ghost.currentIndex].classList.remove("ghost", "scared-ghost");
            //change and add dir to curr index
            ghost.currentIndex += direction;
            squares[ghost.currentIndex].classList.add(ghost.className);
            squares[ghost.currentIndex].classList.add("ghost");
        } else {
            direction = Dir[Math.floor(Math.random() * Dir.length)];
        }

        if (ghost.isScared) {
            squares[ghost.currentIndex].classList.add("scared-ghost");
            if (squares[pacmanCurrentIndex].classList.contains(ghost.className)) {
                squares[ghost.currentIndex].classList.remove(ghost.className, "ghost", "scared-ghost");
                ghost.currentIndex = ghost.startIndex;
                score += 100;
                squares[ghost.currentIndex].classList.add(ghost.className, "ghost");
            }
        }

    }, ghost.speed)
}

// check if it's game over ?

function checkGameOver() {
    if (
        squares[pacmanCurrentIndex].classList.contains("ghost") && 
        !squares[pacmanCurrentIndex].classList.contains("scared-ghost")) {
        ghosts.forEach(ghost => {
            clearInterval(ghost.timerID);
        });
        document.removeEventListener("keyup", control);
        scoreDisplay.textContent = `GAME OVER ! your score is: ${score}.`;
    }
}

// check for win ?

function checkForWin() {
    if (score === 274) {
        ghosts.forEach(ghost => {
            clearInterval(ghost.timerID);
        });
        document.removeEventListener("keyup", control);
        scoreDisplay.textContent = `YOU WON ! your score is: ${score}.`;
    }
}